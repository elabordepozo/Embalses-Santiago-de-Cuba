import subprocess
import sys
import os
import json
import urllib.request
import urllib.error
from datetime import datetime

# ─── CONFIGURACIÓN ───────────────────────────────────────────────
REPO_PATH    = r"C:\Users\Eduardo Laborde\Cuadro-de-Mando-Embalses"
GITHUB_USER  = "elabordepozo"
GITHUB_TOKEN = "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"
REPO_NAME    = "Embalses-Santiago-de-Cuba"
REPO_DESC    = "Cuadro de Mando Hidrológico · Embalses de Santiago de Cuba"
BRANCH       = "main"
# ─────────────────────────────────────────────────────────────────

def run(command, cwd=None):
    result = subprocess.run(
        command, cwd=cwd, shell=True,
        capture_output=True, text=True, encoding="utf-8"
    )
    return result

def run_live(command, cwd=None):
    process = subprocess.Popen(
        command, cwd=cwd, shell=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, encoding="utf-8"
    )
    for line in process.stdout:
        print(f"   {line}", end="")
    process.wait()
    return process.returncode

def create_github_repo():
    """Crea el repositorio en GitHub via API."""
    url = "https://api.github.com/user/repos"
    payload = json.dumps({
        "name": REPO_NAME,
        "description": REPO_DESC,
        "private": False,
        "auto_init": False
    }).encode("utf-8")

    req = urllib.request.Request(url, data=payload, method="POST")
    req.add_header("Authorization", f"token {GITHUB_TOKEN}")
    req.add_header("Accept", "application/vnd.github.v3+json")
    req.add_header("Content-Type", "application/json")

    try:
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read().decode())
            return True, data.get("html_url", "")
    except urllib.error.HTTPError as e:
        body = json.loads(e.read().decode())
        msg = body.get("message", str(e))
        if "already exists" in msg or e.code == 422:
            return "exists", f"https://github.com/{GITHUB_USER}/{REPO_NAME}"
        return False, msg

def main():
    print("=" * 60)
    print("   🚀  CREAR REPO + BUILD + DEPLOY A GITHUB PAGES")
    print("=" * 60)

    if not os.path.exists(REPO_PATH):
        print(f"\n❌ No se encontró la carpeta:\n   {REPO_PATH}")
        sys.exit(1)

    # ── PASO 1: Crear repositorio en GitHub ───────────────────
    print("\n" + "─" * 60)
    print("🐙 PASO 1: Creando repositorio en GitHub...")
    print("─" * 60)

    status, url = create_github_repo()
    if status is False:
        print(f"❌ Error al crear el repositorio: {url}")
        sys.exit(1)
    elif status == "exists":
        print(f"   ℹ️  El repositorio ya existe, continuando...")
    else:
        print(f"   ✅ Repositorio creado: {url}")

    remote_url = f"https://{GITHUB_TOKEN}@github.com/{GITHUB_USER}/{REPO_NAME}.git"
    repo_url   = f"https://github.com/{GITHUB_USER}/{REPO_NAME}"

    # ── PASO 2: Configurar git local ──────────────────────────
    print("\n" + "─" * 60)
    print("⚙️  PASO 2: Configurando git local...")
    print("─" * 60)

    # Inicializar si no tiene .git
    if not os.path.exists(os.path.join(REPO_PATH, ".git")):
        run("git init", cwd=REPO_PATH)
        run(f"git branch -M {BRANCH}", cwd=REPO_PATH)
        print("   ✅ Repositorio git inicializado")

    # Configurar o actualizar el remote
    remotes = run("git remote", cwd=REPO_PATH)
    if "origin" in remotes.stdout:
        run(f"git remote set-url origin {remote_url}", cwd=REPO_PATH)
        print(f"   ✅ Remote 'origin' actualizado → {repo_url}")
    else:
        run(f"git remote add origin {remote_url}", cwd=REPO_PATH)
        print(f"   ✅ Remote 'origin' añadido → {repo_url}")

    # ── PASO 3: Build con Vite ────────────────────────────────
    print("\n" + "─" * 60)
    print("📦 PASO 3: Compilando con Vite (npm run build)...")
    print("─" * 60)

    # Actualizar base en vite.config.ts al nuevo repo
    vite_config_path = os.path.join(REPO_PATH, "vite.config.ts")
    if os.path.exists(vite_config_path):
        with open(vite_config_path, "r", encoding="utf-8") as f:
            content = f.read()
        # Reemplazar cualquier base existente o insertar una nueva
        import re
        new_base = f"base: '/{REPO_NAME}/',"
        if re.search(r"base:\s*'[^']*'", content):
            content = re.sub(r"base:\s*'[^']*',?", new_base, content)
        else:
            content = content.replace("server: {", f"{new_base}\n      server: {")
        with open(vite_config_path, "w", encoding="utf-8") as f:
            f.write(content)
        print(f"   ✅ vite.config.ts actualizado con base '/{REPO_NAME}/'")

    code = run_live("npm run build", cwd=REPO_PATH)
    if code != 0:
        print("\n❌ Error durante el build.")
        sys.exit(1)
    print("\n   ✅ Build completado — carpeta dist/ generada")

    # ── PASO 4: Commit y push del código fuente ───────────────
    print("\n" + "─" * 60)
    print("💾 PASO 4: Commit y push del código fuente...")
    print("─" * 60)

    git_status = run("git status --short", cwd=REPO_PATH)
    if git_status.stdout.strip():
        commit_msg = f"Proyecto inicial - {datetime.now().strftime('%d/%m/%Y %H:%M')}"
        run("git add .", cwd=REPO_PATH)
        commit = run(f'git commit -m "{commit_msg}"', cwd=REPO_PATH)
        if commit.returncode != 0 and "nothing to commit" not in commit.stdout:
            print(f"❌ Error en commit:\n{commit.stderr}")
            sys.exit(1)
        print(f"   ✅ Commit: \"{commit_msg}\"")
    else:
        print("   ℹ️  Sin cambios nuevos en el código fuente")

    push = run(f"git push -u origin {BRANCH}", cwd=REPO_PATH)
    if push.returncode != 0:
        print(f"❌ Error en git push:\n{push.stderr}")
        sys.exit(1)
    print(f"   ✅ Código fuente subido a rama '{BRANCH}'")

    # ── PASO 5: Deploy a GitHub Pages ────────────────────────
    print("\n" + "─" * 60)
    print("🌐 PASO 5: Desplegando en GitHub Pages (rama gh-pages)...")
    print("─" * 60)

    code = run_live(
        f'npx gh-pages -d dist -m "Deploy GitHub Pages" -u "github-actions-bot <actions@github.com>"',
        cwd=REPO_PATH
    )
    if code != 0:
        print("\n❌ Error al desplegar.")
        print("\n💡 Ve a GitHub → Settings → Pages → Source → gh-pages / root")
        sys.exit(1)

    # ── PASO 6: Activar GitHub Pages via API ─────────────────
    print("\n" + "─" * 60)
    print("⚙️  PASO 6: Activando GitHub Pages via API...")
    print("─" * 60)

    pages_url = f"https://api.github.com/repos/{GITHUB_USER}/{REPO_NAME}/pages"
    pages_payload = json.dumps({
        "source": {"branch": "gh-pages", "path": "/"}
    }).encode("utf-8")
    req = urllib.request.Request(pages_url, data=pages_payload, method="POST")
    req.add_header("Authorization", f"token {GITHUB_TOKEN}")
    req.add_header("Accept", "application/vnd.github.v3+json")
    req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req) as resp:
            print("   ✅ GitHub Pages activado automáticamente")
    except urllib.error.HTTPError as e:
        body = e.read().decode()
        if "already enabled" in body or e.code in (409, 422):
            print("   ℹ️  GitHub Pages ya estaba activado")
        else:
            print(f"   ⚠️  Actívalo manualmente: Settings → Pages → gh-pages / root")

    # ── RESUMEN ───────────────────────────────────────────────
    print("\n" + "=" * 60)
    print("   🎉  ¡TODO LISTO!")
    print("=" * 60)
    print(f"\n📂 Repositorio:  {repo_url}")
    print(f"🌐 GitHub Pages: https://{GITHUB_USER}.github.io/{REPO_NAME}/")
    print(f"\n⏳ La web puede tardar 1-2 minutos en estar disponible.\n")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"\n❌ Error inesperado: {e}")
    finally:
        input("\nPresiona ENTER para cerrar...")
